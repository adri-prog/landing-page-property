/* README.md */
# Landing Page Properti

Landing page responsif untuk mempromosikan unit properti ke pelanggan.

## Fitur:
- Mode terang & gelap
- Multi unit (Tipe rumah)
- Admin dashboard (statik dummy)
- SEO friendly
- Siap deploy ke Netlify / Vercel

## Deploy Cepat:
1. Clone repo
2. Ganti gambar & konten di `assets/`
3. Deploy folder ke Netlify

---
